from .bot import Bot

def start():
    bot = Bot()
    bot.run() 

# bot = Bot()

# if __name__ == '__main__':
    
#     bot.run()